
Please see the file LICENSE.txt for license information.

Please see the Oculus SDK Overview in the OculusSDK/Doc/ directory for more information.