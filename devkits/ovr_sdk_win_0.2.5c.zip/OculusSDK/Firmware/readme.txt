Firmware packages for Oculus products are stored in this folder.
Use the OculusConfigUtil to load them and update your products.

Tracker DK Firmware Version History
===================================

0.18 - 2013-10-03
* Resolve a calibration issue that could result in additional
  drift in certain conditions.
* Resolve a calibration issue that resulted in additional drift
  after fast motions.

0.17 - 2013-04-24
* Fix an issue where the Tracker can fail to initialize with
  Logitech software running.

0.16 - 2013-03-13
* Release firmware for the Oculus Rift DK.

